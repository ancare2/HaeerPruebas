# Mi Paquete

Este es un paquete de ejemplo que incluye operaciones matemáticas y de cadenas.

## Instalación

Puedes instalar el paquete usando pip:

```bash
pip install .
