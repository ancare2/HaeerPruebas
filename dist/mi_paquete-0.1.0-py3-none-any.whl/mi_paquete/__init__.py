# mi_paquete/__init__.py

from .math_operations import add, subtract
from .string_operations import concatenate

__all__ = ["add", "subtract", "concatenate"]
