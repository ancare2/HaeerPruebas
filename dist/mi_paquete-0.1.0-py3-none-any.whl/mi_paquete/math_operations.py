# mi_paquete/math_operations.py

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
